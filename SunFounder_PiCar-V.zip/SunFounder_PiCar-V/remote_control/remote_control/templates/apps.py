from __future__ import unicode_literals

from django.apps import AppConfig


class TemplatesConfig(AppConfig):
    name = 'remote_control.templates'
