## Datasheets

This folder contains the main IC datasheets for this Kit.

PCB contains chips:
 - Robot HATS:
     + MP1593
     + PCF8591
 - PCA9685:
     + PCA9685
 - TB6612:
     + TB6612FNG